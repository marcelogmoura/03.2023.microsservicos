package com.mgmoura.payrollapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayrollApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
